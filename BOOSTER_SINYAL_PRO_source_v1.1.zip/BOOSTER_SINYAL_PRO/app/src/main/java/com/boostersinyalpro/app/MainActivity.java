package com.boostersinyalpro.app;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.*;
import android.net.*;
import android.view.View;
import android.view.Window;
import android.widget.*;
import java.util.List;

public class MainActivity extends Activity {
    int bg=Color.rgb(4,11,20), card=Color.rgb(13,23,41), cyan=Color.rgb(0,220,245), white=Color.rgb(235,244,255), muted=Color.rgb(150,166,187);
    TelephonyManager tm; TextView dbm,quality,network,connection,status; final int REQ=100;
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    GradientDrawable shape(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(4));return d;}
    TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    LinearLayout panel(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setBackground(shape(card));pad(l,18,18,18,18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);l.setLayoutParams(p);return l;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.rgb(0,20,30));b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setBackground(shape(cyan));b.setMinHeight(dp(56));b.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));return b;}
    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);tm=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);ui();if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},REQ);else refresh();}
    void ui(){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg);LinearLayout r=new LinearLayout(this);r.setOrientation(1);pad(r,20,28,20,24);sc.addView(r);setContentView(sc);
        r.addView(txt("N E T W O R K   I N T E L L I G E N C E",12,cyan,true));TextView title=txt("BOOSTER\\nSINYAL PRO",34,white,true);pad(title,0,18,0,8);r.addView(title);r.addView(txt("Pemantauan sinyal SIM & data seluler",16,muted,false));status=txt("● MENYIAPKAN PEMANTAUAN",14,cyan,true);pad(status,0,26,0,18);r.addView(status);
        LinearLayout a=panel();a.addView(txt("01 / SINYAL SELULER",13,cyan,true));dbm=txt("Membaca sinyal…",32,white,true);pad(dbm,0,20,0,2);a.addView(dbm);quality=txt("Menunggu izin pembacaan modem",14,muted,false);a.addView(quality);TextView note=txt("Nilai dBm yang lebih dekat ke 0 umumnya menandakan sinyal lebih kuat.",12,muted,false);pad(note,0,12,0,0);a.addView(note);r.addView(a);
        LinearLayout n=panel();n.addView(txt("02 / JARINGAN SELULER",13,cyan,true));network=txt("Memeriksa 4G / 5G…",23,white,true);pad(network,0,18,0,5);n.addView(network);n.addView(txt("Jenis jaringan yang dilaporkan Android. Ikon 5G di status bar tidak selalu berarti data sedang memakai NR setiap saat.",12,muted,false));r.addView(n);
        LinearLayout c=panel();c.addView(txt("03 / KONEKSI AKTIF",13,cyan,true));connection=txt("Memeriksa koneksi…",18,white,true);pad(connection,0,16,0,0);c.addView(connection);r.addView(c);
        Button refresh=btn("⟳   PERBARUI STATUS");refresh.setOnClickListener(v->refresh());r.addView(refresh);
        Button settings=btn("BUKA PENGATURAN JARINGAN SELULER");LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)settings.getLayoutParams();p.topMargin=dp(14);settings.setLayoutParams(p);settings.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));}catch(Exception e){startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));}});r.addView(settings);
        TextView foot=txt("CATATAN • Aplikasi memantau informasi yang disediakan Android. Aplikasi tidak dapat memperkuat gelombang radio secara fisik.",12,muted,false);pad(foot,0,24,0,0);r.addView(foot);
    }
    void refresh(){if(status==null)return;status.setText("● PEMANTAUAN DIPERBARUI");readSignal();readNetwork();readConnection();}
    void readSignal(){
        if(Build.VERSION.SDK_INT<29){dbm.setText("Tidak tersedia");quality.setText("Android ini tidak menyediakan pembacaan melalui metode aplikasi.");return;}
        if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){dbm.setText("Izin diperlukan");quality.setText("Izinkan akses Telepon untuk membaca sinyal.");return;}
        try{SignalStrength ss=tm.getSignalStrength();int val=Integer.MAX_VALUE;if(ss!=null){List<CellSignalStrength> list=ss.getCellSignalStrengths();for(CellSignalStrength s:list){int x=s.getDbm();if(x<0&&x>-200){val=x;break;}}}
            if(val==Integer.MAX_VALUE){dbm.setText("Belum tersedia");quality.setText("Modem belum memberikan nilai dBm. Coba perbarui lagi.");}
            else{dbm.setText(val+" dBm");String q=val>=-85?"Sangat baik":val>=-100?"Baik":val>=-110?"Cukup":"Lemah";quality.setText("Kualitas perkiraan: "+q+" • Pembacaan Android");}
        }catch(Exception e){dbm.setText("Tidak tersedia");quality.setText("Pembacaan modem tidak tersedia pada perangkat ini.");}
    }
    void readNetwork(){try{if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){network.setText("Izin telepon diperlukan");return;}int t=tm.getDataNetworkType();String s;
        switch(t){case TelephonyManager.NETWORK_TYPE_NR:s="5G NR";break;case TelephonyManager.NETWORK_TYPE_LTE:s="4G LTE";break;case TelephonyManager.NETWORK_TYPE_HSPAP:case TelephonyManager.NETWORK_TYPE_HSPA:case TelephonyManager.NETWORK_TYPE_HSDPA:case TelephonyManager.NETWORK_TYPE_HSUPA:case TelephonyManager.NETWORK_TYPE_UMTS:s="3G / HSPA";break;case TelephonyManager.NETWORK_TYPE_EDGE:case TelephonyManager.NETWORK_TYPE_GPRS:s="2G";break;default:s="Tidak diketahui / jaringan campuran";}network.setText(s);
        }catch(Exception e){network.setText("Informasi jaringan tidak tersedia");}}
    void readConnection(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);Network a=cm.getActiveNetwork();NetworkCapabilities c=a==null?null:cm.getNetworkCapabilities(a);if(c!=null&&c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))connection.setText("Data seluler • Terhubung");else if(c!=null&&c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))connection.setText("Wi-Fi • Terhubung");else connection.setText("Belum ada koneksi internet aktif");}catch(Exception e){connection.setText("Status koneksi tidak tersedia");}}
    public void onRequestPermissionsResult(int q,String[] p,int[] g){super.onRequestPermissionsResult(q,p,g);if(q==REQ){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)refresh();else{status.setText("● IZIN DIPERLUKAN");dbm.setText("Izin belum diberikan");quality.setText("Izinkan akses Telepon melalui dialog Android untuk membaca sinyal.");readConnection();}}}
    protected void onResume(){super.onResume();if(dbm!=null&&checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED)refresh();}
}
