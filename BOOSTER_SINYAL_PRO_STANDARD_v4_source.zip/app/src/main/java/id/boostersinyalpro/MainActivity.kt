package id.boostersinyalpro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.*
import android.os.Bundle
import android.provider.Settings
import android.telephony.*
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg=Color.rgb(5,12,20); private val panel=Color.rgb(14,25,43)
    private val cyan=Color.rgb(0,218,238); private val white=Color.rgb(238,246,255)
    private val grey=Color.rgb(158,176,197)
    private lateinit var tm:TelephonyManager; private lateinit var cm:ConnectivityManager
    private val io=Executors.newSingleThreadExecutor()
    private lateinit var signal:TextView; private lateinit var radio:TextView
    private lateinit var metrics:TextView; private lateinit var connection:TextView
    private lateinit var diagnosis:TextView; private lateinit var result:TextView
    private lateinit var resultDetail:TextView; private lateinit var progress:ProgressBar
    private lateinit var testButton:Button; private lateinit var refreshButton:Button
    private var busy=false; private var rsrp:Int?=null; private var rsrq:Int?=null; private var sinr:Int?=null

    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        tm=getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        cm=getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        buildUi(); requestPermissionsIfNeeded(); refreshAll()
    }
    private fun buildUi() {
        val scroll=ScrollView(this).apply{setBackgroundColor(bg)}
        val root=LinearLayout(this).apply{orientation=1;setPadding(dp(20),dp(24),dp(20),dp(28))}
        scroll.addView(root);setContentView(scroll)
        root.addView(text("NETWORK OPTIMIZATION • STANDARD",cyan,12f,true))
        root.addView(text("BOOSTER\nSINYAL PRO",white,34f,true))
        root.addView(text("SMARTFREN • 4G LTE / 5G NR • NO ROOT",grey,13f,true))
        root.addView(text("Diagnosis + tindakan optimasi + pengujian sebelum/sesudah.",grey,14f,false))
        section(root,"01 / KONDISI RADIO")
        val a=card(root);signal=text("-- dBm",white,30f,true);a.addView(signal)
        metrics=text("Membaca metrik radio dari Android…",grey,13f,false);a.addView(metrics)
        radio=text("Jaringan: memeriksa…",white,18f,true);a.addView(radio)
        connection=text("Koneksi aktif: memeriksa…",grey,13f,false);a.addView(connection)
        refreshButton=button("PERBARUI DIAGNOSIS"){refreshAll()};root.addView(refreshButton,lp())
        section(root,"02 / SMART OPTIMIZER")
        val b=card(root);diagnosis=text("Belum ada diagnosis.",white,15f,false);b.addView(diagnosis)
        root.addView(button("PANDUAN SEGARKAN JARINGAN"){showRefreshGuide()},lp())
        root.addView(button("BUKA PENGATURAN JARINGAN"){openSettings(Settings.ACTION_WIRELESS_SETTINGS)},lp())
        section(root,"03 / UJI KONEKSI SELULER")
        val c=card(root);result=text("Belum dites",white,24f,true);c.addView(result)
        resultDetail=text("Tes hanya berjalan jika koneksi aktif terdeteksi sebagai data seluler. Perkiraan kuota ±4 MB.",grey,13f,false);c.addView(resultDetail)
        progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100;progressTintList=android.content.res.ColorStateList.valueOf(cyan)}
        c.addView(progress,lp())
        testButton=button("TES DOWNLOAD • UPLOAD • LATENSI"){runSpeedTest()};root.addView(testButton,lp())
        section(root,"04 / CARA MENGGUNAKAN OPTIMASI")
        root.addView(text("1. Jalankan diagnosis dan tes awal. 2. Ikuti rekomendasi posisi atau segarkan koneksi secara manual. 3. Tunggu jaringan kembali stabil. 4. Jalankan tes ulang di lokasi dan kondisi yang sama. Bandingkan hasilnya; jika tidak membaik, jangan anggap optimasi berhasil.",grey,13f,false))
        section(root,"BATASAN JUJUR")
        root.addView(text("Aplikasi Standard tanpa root tidak dapat memperkuat antena, menaikkan daya radio, memilih band LTE/5G, memaksa 5G, atau mengubah modem. Kontrol tersebut dibatasi Android/OEM/operator. Aplikasi ini melakukan tindakan yang diizinkan dan mengukur hasil nyata.",grey,12f,false))
    }
    private fun section(root:LinearLayout,s:String){root.addView(text(s,cyan,13f,true).apply{setPadding(0,dp(18),0,dp(8))})}
    private fun card(root:LinearLayout)=LinearLayout(this).apply{orientation=1;setPadding(dp(15),dp(14),dp(15),dp(14));setBackgroundColor(panel);root.addView(this,lp())}
    private fun text(s:String,c:Int,z:Float,b:Boolean)=TextView(this).apply{text=s;setTextColor(c);textSize=z;if(b)setTypeface(typeface,Typeface.BOLD);setPadding(0,dp(4),0,dp(5));setLineSpacing(dp(2).toFloat(),1f)}
    private fun button(s:String,act:()->Unit)=Button(this).apply{text=s;isAllCaps=false;textSize=13f;setTextColor(bg);backgroundTintList=android.content.res.ColorStateList.valueOf(cyan);setTypeface(typeface,Typeface.BOLD);setOnClickListener{act()}}
    private fun lp()=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(9)}
    private fun dp(n:Int)=(n*resources.displayMetrics.density).roundToInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()

    private fun requestPermissionsIfNeeded(){
        val p=mutableListOf<String>()
        if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_PHONE_STATE)
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if(p.isNotEmpty())requestPermissions(p.toTypedArray(),10)
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==10)refreshAll()}
    override fun onResume(){super.onResume();if(::signal.isInitialized)refreshAll()}

    private fun refreshAll(){
        val caps=cm.getNetworkCapabilities(cm.activeNetwork)
        val cell=caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)==true
        val wifi=caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true
        connection.text=when{cell->"Koneksi aktif: DATA SELULER";wifi->"Koneksi aktif: WI-FI (tes seluler dinonaktifkan)";else->"Koneksi aktif: tidak terdeteksi"}
        val tech=runCatching{@Suppress("DEPRECATION") when(tm.dataNetworkType){
            TelephonyManager.NETWORK_TYPE_NR->"5G NR";TelephonyManager.NETWORK_TYPE_LTE->"4G LTE"
            TelephonyManager.NETWORK_TYPE_HSPAP,TelephonyManager.NETWORK_TYPE_HSPA,TelephonyManager.NETWORK_TYPE_HSDPA,TelephonyManager.NETWORK_TYPE_HSUPA,TelephonyManager.NETWORK_TYPE_UMTS->"3G"
            TelephonyManager.NETWORK_TYPE_EDGE,TelephonyManager.NETWORK_TYPE_GPRS->"2G"
            else->"Radio tidak diketahui / dibatasi"}}.getOrDefault("Tidak tersedia")
        val op=runCatching{tm.networkOperatorName}.getOrNull().orEmpty().ifBlank{"Operator tidak tersedia"}
        radio.text="$tech • $op"
        readCellMetrics()
    }
    private fun readCellMetrics(){
        val granted=checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED &&
            (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)
        if(!granted){signal.text="Izin diperlukan";metrics.text="Izinkan Telepon dan Lokasi, lalu aktifkan layanan Lokasi Android.";return}
        io.execute{
            val data=runCatching{
                @Suppress("DEPRECATION") val cells=tm.allCellInfo?: emptyList()
                val s=(cells.firstOrNull{it.isRegistered}?:cells.firstOrNull())?.cellSignalStrength
                var p:Int?=null;var q:Int?=null;var n:Int?=null
                when(s){
                    is CellSignalStrengthLte->{p=s.rsrp.takeIf{it in -160..0};q=s.rsrq.takeIf{it in -50..0};n=s.rssnr.takeIf{it in -200..300}}
                    is CellSignalStrengthNr->{p=s.ssRsrp.takeIf{it in -160..0};q=s.ssRsrq.takeIf{it in -50..0};n=s.ssSinr.takeIf{it in -200..300}}
                }
                arrayOf(s?.dbm?.takeIf{it in -200..0},p,q,n)
            }.getOrNull()
            runOnUiThread{
                if(data==null||data[0]==null){signal.text="Metrik tidak tersedia";metrics.text="Modem/firmware tidak memberikan nilai. Pastikan Lokasi aktif dan coba lagi."}
                else{
                    signal.text="${data[0]} dBm";rsrp=data[1];rsrq=data[2];sinr=data[3]
                    metrics.text=listOfNotNull(rsrp?.let{"RSRP $it dBm"},rsrq?.let{"RSRQ $it dB"},sinr?.let{"SINR $it dB"}).joinToString(" • ").ifBlank{"Metrik lanjutan tidak diberikan Android"}
                    diagnose()
                }
            }
        }
    }
    private fun diagnose(){
        diagnosis.text=when{
            rsrp!=null&&rsrp!!<=-115->"PENERIMAAN LEMAH. Coba dekat jendela/area terbuka, ubah orientasi HP, dan jauhkan dari logam. Uji ulang. Jika tetap lemah, kemungkinan cakupan indoor/lokasi BTS."
            rsrp!=null&&rsrp!!<=-105->"PENERIMAAN SEDANG-LEMAH. Bandingkan 2–3 posisi HP. Gunakan hasil tes kecepatan untuk melihat apakah masalah juga terkait kepadatan jaringan."
            sinr!=null&&sinr!!<0->"KUALITAS RADIO TERGANGGU. SINR rendah dapat menunjukkan interferensi/kualitas sel. Coba lokasi berbeda atau waktu jaringan lebih sepi."
            rsrq!=null&&rsrq!!<=-15->"KUALITAS SEL KURANG BAIK. RSRQ rendah dapat berkaitan dengan beban sel atau kualitas radio. Bandingkan tes pada waktu berbeda."
            else->"BELUM ADA MASALAH RADIO YANG JELAS. Jalankan tes internet. Kecepatan rendah dengan sinyal baik dapat berasal dari kepadatan sel, routing, server, atau paket operator."
        }
    }
    private fun showRefreshGuide(){
        diagnosis.text="PENYEGARAN MANUAL: 1) Buka pengaturan Mode Pesawat. 2) Aktifkan 10–15 detik. 3) Matikan kembali. 4) Tunggu Smartfren tersambung lagi. 5) Kembali ke aplikasi, perbarui diagnosis dan tes ulang. Ini meminta modem registrasi ulang; hasilnya tidak dijamin lebih baik."
        openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
    }
    private fun openSettings(action:String){runCatching{startActivity(Intent(action))}.onFailure{toast("Halaman pengaturan tidak tersedia; buka Pengaturan Android secara manual.")}}

    private data class TestResult(val ping:Long,val down:String,val up:String,val error:String?=null)
    private fun runSpeedTest(){
        if(busy)return
        val active=cm.activeNetwork;val caps=cm.getNetworkCapabilities(active)
        if(active==null||caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)!=true){
            toast("Tes hanya untuk data seluler. Matikan Wi-Fi dan aktifkan data Smartfren.");return}
        busy=true;testButton.isEnabled=false;refreshButton.isEnabled=false;progress.progress=5
        result.text="Tes berjalan…";resultDetail.text="Mengukur lewat jaringan seluler aktif. Kuota sekitar 4 MB."
        io.execute{
            val r=runCatching{measure(active)}.getOrElse{TestResult(0,"","",it.message?:"Koneksi gagal")}
            runOnUiThread{
                busy=false;testButton.isEnabled=true;refreshButton.isEnabled=true;progress.progress=100
                if(r.error!=null){result.text="Tes gagal";resultDetail.text=r.error}
                else{result.text="${r.down} Mbps ↓  •  ${r.up} Mbps ↑";resultDetail.text="Latensi HTTPS median ${r.ping} ms. Ulangi pada kondisi serupa untuk membandingkan hasil."}
            }
        }
    }
    private fun measure(network:Network):TestResult{
        val samples=mutableListOf<Long>()
        repeat(3){i->
            val c=network.openConnection(URL("https://www.cloudflare.com/cdn-cgi/trace?bsp=${System.nanoTime()}-$i")) as HttpURLConnection
            c.connectTimeout=10000;c.readTimeout=10000;val start=System.nanoTime()
            try{c.inputStream.use{it.read(ByteArray(256))};if(c.responseCode in 200..399)samples.add((System.nanoTime()-start)/1_000_000)}finally{c.disconnect()}
        }
        if(samples.isEmpty())return TestResult(0,"","", "Server latensi tidak dapat dijangkau.")
        val ping=samples.sorted()[1]
        val amount=3_000_000
        val d=network.openConnection(URL("https://speed.cloudflare.com/__down?bytes=$amount&bsp=${System.nanoTime()}")) as HttpURLConnection
        d.connectTimeout=15000;d.readTimeout=20000;var got=0L;val ds=System.nanoTime()
        try{d.inputStream.use{input->val buf=ByteArray(32768);while(true){val n=input.read(buf);if(n<0)break;got+=n;if(got>=amount)break}}}finally{d.disconnect()}
        val sec=((System.nanoTime()-ds).coerceAtLeast(1L))/1e9
        if(got<100000)return TestResult(ping,"","", "Data download terlalu sedikit diterima.")
        val down=got*8/sec/1_000_000.0
        val payload=ByteArray(1_000_000).also{java.security.SecureRandom().nextBytes(it)}
        val u=network.openConnection(URL("https://speed.cloudflare.com/__up")) as HttpURLConnection
        u.connectTimeout=15000;u.readTimeout=20000;u.requestMethod="POST";u.doOutput=true;u.setFixedLengthStreamingMode(payload.size);u.setRequestProperty("Content-Type","application/octet-stream")
        val us=System.nanoTime();val code:Int
        try{u.outputStream.use{it.write(payload)};code=u.responseCode;runCatching{u.inputStream?.close()}}finally{u.disconnect()}
        val usec=((System.nanoTime()-us).coerceAtLeast(1L))/1e9
        if(code !in 200..299)return TestResult(ping,String.format(Locale.US,"%.1f",down),"","Server upload memberi HTTP $code.")
        val up=payload.size*8/usec/1_000_000.0
        return TestResult(ping,String.format(Locale.US,"%.1f",down),String.format(Locale.US,"%.1f",up))
    }
    override fun onDestroy(){io.shutdownNow();super.onDestroy()}
}
