# BOOSTER SINYAL PRO — Android

Aplikasi Android native sederhana untuk memantau informasi sinyal SIM dan Wi-Fi dengan tampilan dark premium hitam/biru neon.

## Fitur yang diimplementasikan
- Pemantauan RSSI Wi-Fi (dBm) saat terhubung.
- Pembacaan kekuatan sinyal seluler melalui API Android yang tersedia pada perangkat.
- Status jenis koneksi aktif.
- Tombol pintas ke pengaturan jaringan seluler dan Wi-Fi.
- Antarmuka dark premium.

## Batasan teknis
Aplikasi Android biasa tidak dapat meningkatkan daya pancar radio atau menjamin sinyal lebih kuat. Nilai sinyal SIM dapat tidak tersedia karena keterbatasan modem, operator, izin, atau versi Android. Pembacaan Wi-Fi juga bergantung pada kebijakan Android dan perangkat.

## Cara membangun APK
1. Instal Android Studio di komputer.
2. Buka folder `BOOSTER_SINYAL_PRO` sebagai project.
3. Pastikan Android SDK Platform 35 dan Android Gradle Plugin/Gradle yang sesuai terpasang.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Source ini adalah project Android Studio, bukan APK yang sudah dikompilasi. Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle untuk menghasilkan dan menguji APK secara langsung.
