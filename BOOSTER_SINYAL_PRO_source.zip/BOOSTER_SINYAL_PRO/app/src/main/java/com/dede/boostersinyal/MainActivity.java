package com.dede.boostersinyal;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 11, 18);
    private final int CARD = Color.rgb(15, 23, 38);
    private final int BLUE = Color.rgb(34, 211, 238);
    private final int WHITE = Color.rgb(235, 245, 255);
    private final int MUTED = Color.rgb(148, 163, 184);
    private TextView simValue, simDetail, wifiValue, wifiDetail, networkValue, status;
    private TelephonyManager telephonyManager;
    private int cellularDbm = Integer.MIN_VALUE;
    private PhoneStateListener phoneListener;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        requestNeededPermissions();
        refreshAll();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(root);

        TextView eyebrow = text("NETWORK INTELLIGENCE", 11, BLUE, true);
        eyebrow.setLetterSpacing(0.15f);
        root.addView(eyebrow);

        TextView title = text("BOOSTER\nSINYAL PRO", 30, WHITE, true);
        title.setLineSpacing(0, 0.95f);
        LinearLayout.LayoutParams titleLp = params(-1, -2);
        titleLp.topMargin = dp(7);
        root.addView(title, titleLp);

        TextView subtitle = text("Pantau kualitas koneksi SIM & Wi-Fi", 14, MUTED, false);
        LinearLayout.LayoutParams subLp = params(-1, -2);
        subLp.topMargin = dp(8);
        root.addView(subtitle, subLp);

        status = text("●  MENYIAPKAN PEMANTAUAN", 12, BLUE, true);
        LinearLayout.LayoutParams statusLp = params(-1, -2);
        statusLp.topMargin = dp(22);
        root.addView(status, statusLp);

        LinearLayout simCard = card(root, "01  /  SINYAL SELULER");
        simValue = text("-- dBm", 32, WHITE, true);
        simCard.addView(simValue);
        simDetail = text("Memeriksa kekuatan sinyal SIM…", 13, MUTED, false);
        simCard.addView(simDetail, params(-1, -2));
        TextView simNote = text("Nilai dBm lebih dekat ke 0 umumnya berarti sinyal lebih kuat.", 11, MUTED, false);
        LinearLayout.LayoutParams noteLp = params(-1, -2); noteLp.topMargin = dp(10);
        simCard.addView(simNote, noteLp);

        LinearLayout wifiCard = card(root, "02  /  WI-FI");
        wifiValue = text("-- dBm", 32, WHITE, true);
        wifiCard.addView(wifiValue);
        wifiDetail = text("Memeriksa koneksi Wi-Fi…", 13, MUTED, false);
        wifiCard.addView(wifiDetail, params(-1, -2));

        LinearLayout netCard = card(root, "03  /  KONEKSI AKTIF");
        networkValue = text("Memeriksa jaringan…", 16, WHITE, true);
        netCard.addView(networkValue);

        Button refresh = button("⟳   PERBARUI STATUS");
        root.addView(refresh, buttonParams());
        refresh.setOnClickListener(v -> refreshAll());

        Button mobile = button("BUKA PENGATURAN JARINGAN SELULER");
        root.addView(mobile, buttonParams());
        mobile.setOnClickListener(v -> openSettings(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));

        Button wifi = button("BUKA PENGATURAN WI-FI");
        root.addView(wifi, buttonParams());
        wifi.setOnClickListener(v -> openSettings(Settings.ACTION_WIFI_SETTINGS));

        TextView disclaimer = text("CATATAN  •  Aplikasi ini mengukur sinyal dan membuka pengaturan Android. Aplikasi tidak dapat memperkuat gelombang radio secara fisik atau menjamin peningkatan kecepatan.", 11, MUTED, false);
        LinearLayout.LayoutParams discLp = params(-1, -2);
        discLp.topMargin = dp(18);
        root.addView(disclaimer, discLp);

        TextView footer = text("DSP • NETWORK TOOLS  /  V1.0", 10, BLUE, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = params(-1, -2); footLp.topMargin = dp(22);
        root.addView(footer, footLp);

        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(16), dp(17), dp(17));
        box.setBackgroundColor(CARD);
        LinearLayout.LayoutParams lp = params(-1, -2);
        lp.topMargin = dp(16);
        parent.addView(box, lp);
        TextView h = text(heading, 11, BLUE, true);
        h.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams hlp = params(-1, -2);
        hlp.bottomMargin = dp(13);
        box.addView(h, hlp);
        return box;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(BG);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = params(-1, dp(52));
        p.topMargin = dp(12);
        return p;
    }

    private LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> asks = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
                asks.add(Manifest.permission.READ_PHONE_STATE);
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                asks.add(Manifest.permission.ACCESS_FINE_LOCATION);
            if (!asks.isEmpty()) requestPermissions(asks.toArray(new String[0]), 42);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshAll();
    }

    private void refreshAll() {
        updateWifi();
        updateActiveNetwork();
        updateCellular();
        status.setText("●  PEMANTAUAN DIPERBARUI");
    }

    @SuppressWarnings("deprecation")
    private void updateWifi() {
        try {
            WifiManager wm = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) {
                wifiValue.setText("NONAKTIF");
                wifiDetail.setText("Wi-Fi mati. Aktifkan melalui pengaturan Wi-Fi.");
                return;
            }
            android.net.wifi.WifiInfo info = wm.getConnectionInfo();
            if (info == null || info.getNetworkId() == -1) {
                wifiValue.setText("BELUM TERHUBUNG");
                wifiDetail.setText("Pilih jaringan Wi-Fi untuk mengukur RSSI.");
                return;
            }
            int rssi = info.getRssi();
            wifiValue.setText(rssi + " dBm");
            int level = WifiManager.calculateSignalLevel(rssi, 5);
            String quality = level >= 4 ? "Sangat baik" : level >= 3 ? "Baik" : level >= 2 ? "Sedang" : "Lemah";
            wifiDetail.setText("Kualitas perkiraan: " + quality + "  •  Level " + (level + 1) + "/5");
        } catch (Exception e) {
            wifiValue.setText("TIDAK TERSEDIA");
            wifiDetail.setText("Android membatasi akses informasi Wi-Fi pada perangkat ini.");
        }
    }

    private void updateActiveNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities caps = n == null || cm == null ? null : cm.getNetworkCapabilities(n);
            if (caps == null) networkValue.setText("Tidak ada koneksi terdeteksi");
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) networkValue.setText("Wi-Fi  •  Terhubung");
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) networkValue.setText("Data seluler  •  Terhubung");
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) networkValue.setText("Ethernet  •  Terhubung");
            else networkValue.setText("Jaringan aktif terdeteksi");
        } catch (Exception e) {
            networkValue.setText("Status jaringan tidak tersedia");
        }
    }

    @SuppressWarnings("deprecation")
    private void updateCellular() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            simValue.setText("IZIN DIPERLUKAN");
            simDetail.setText("Izinkan akses status telepon agar pembacaan sinyal SIM dapat dicoba.");
            return;
        }
        try {
            telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager == null) {
                simValue.setText("TIDAK TERSEDIA");
                simDetail.setText("Layanan telepon tidak ditemukan.");
                return;
            }
            if (phoneListener != null) {
                try { telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) {}
            }
            phoneListener = new PhoneStateListener() {
                @Override public void onSignalStrengthsChanged(SignalStrength strength) {
                    super.onSignalStrengthsChanged(strength);
                    try {
                        int dbm = strength.getCellSignalStrengths().isEmpty() ? Integer.MIN_VALUE :
                                  strength.getCellSignalStrengths().get(0).getDbm();
                        cellularDbm = dbm;
                        runOnUiThread(() -> {
                            if (dbm == Integer.MIN_VALUE || dbm == 0) {
                                simValue.setText("MENUNGGU…");
                                simDetail.setText("Tunggu pembaruan dari modem; hasil bergantung perangkat/operator.");
                            } else {
                                simValue.setText(dbm + " dBm");
                                String q = dbm >= -85 ? "Sangat baik" : dbm >= -100 ? "Cukup" : "Lemah";
                                simDetail.setText("Kualitas perkiraan: " + q + "  •  Pembacaan modem");
                            }
                        });
                    } catch (Exception ignored) {}
                }
            };
            telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            if (cellularDbm == Integer.MIN_VALUE) {
                simValue.setText("MENUNGGU…");
                simDetail.setText("Menunggu laporan modem. Beberapa perangkat tidak menyediakan nilai dBm.");
            }
        } catch (SecurityException e) {
            simValue.setText("AKSES DIBATASI");
            simDetail.setText("Perangkat atau versi Android membatasi pembacaan sinyal SIM.");
        } catch (Exception e) {
            simValue.setText("TIDAK TERSEDIA");
            simDetail.setText("Pembacaan sinyal SIM tidak didukung pada perangkat ini.");
        }
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Pengaturan tidak dapat dibuka.", Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override protected void onDestroy() {
        if (telephonyManager != null && phoneListener != null) {
            try { telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
